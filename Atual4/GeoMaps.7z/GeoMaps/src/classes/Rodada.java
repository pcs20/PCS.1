/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author alexsander
 */
public class Rodada {
    public ArrayList<Integer> SorteaEstadoPais;//vai armazena um valor para ser jogado no vetor da classe Estados para gerar minha imagem do mapa
    public int randomNum;
    
    public Rodada(){
        SorteaEstadoPais = new ArrayList<Integer>();
    }

    public boolean verificaLista(int verifica) {//verifica se o valor gerado pela função QuestRandInt já existe ou não na lista SorteaEstadoPais. Se não existir, ele inclui na lista
        if (SorteaEstadoPais.contains(verifica)) {
            return false;
        } else {
            SetList(verifica);
        }
        return true;
    }
    
    public int QuestRandInt(int min, int max) {// gera um número aleatório entre 0 e 14 por exemplo para os estados que só existem 15 opções
        java.util.Random rand = new java.util.Random();
        randomNum = rand.nextInt((max - min) + 1) + min;

        while (!verificaLista(randomNum)) {
            randomNum = rand.nextInt((max - min) + 1) + min;
        }
        return randomNum;//vai retornar 2
    }

    public void ClearList() {//apaga lista, pois, o usuário pode optar por jogar novamente e é preciso que a lista esteja vazia a cada rodada
        SorteaEstadoPais.clear();
    }

    public void SetList(int val) {//inclui valores na lista
        SorteaEstadoPais.add(val);
    }

    public boolean ListaCheia(int max) {//verifica se a lista está cheia
        if (SorteaEstadoPais.size() == max) {
            return true;
        } else {
            return false;
        }
    }
}
