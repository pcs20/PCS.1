/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author alexsander
 */
public class continente {
    public String[] Continente = new String[255];
    
    public continente(){
        Continente[0] = "África";
        Continente[1] = "América Central";
        Continente[2] = "América do Norte";
        Continente[3] = "América do Sul";
        Continente[4] = "Ásia";
        Continente[5] = "Europa";
        Continente[6] = "Oceania";
    }
}
