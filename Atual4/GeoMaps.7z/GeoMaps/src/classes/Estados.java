/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author alexsander
 */
public class Estados {
    public String[] estados = new String[255];
    
    public Estados(){
        estados[0] = "Acre";
        estados[14] = "Mato Grosso";
        estados[13] = "São Paulo";
        estados[12] = "Roraima";
        estados[11] = "Piauí";
        estados[10] = "Paraíba";
        estados[9] = "Rio de Janeiro";
        estados[8] = "Goias";
        estados[7] = "Espiríto Santo";
        estados[6] = "Distrito Federal";
        estados[5] = "Ceará";
        estados[4] = "Bahia";
        estados[3] = "Amazonas";
        estados[2] = "Amapa";
        estados[1] = "Alagoas";
    }
}
