/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

/**
 *
 * @author alexsander
 */
public class oceano {
    public String[] oceano = new String[255];
    
    public oceano(){
        oceano[0] = "Oceano Atlântico";
        oceano[1] = "Oceano Glacial Antártico";
        oceano[2] = "Oceano Glacial Ártico";
        oceano[3] = "Oceano índico";
        oceano[4] = "Oceano Pacífico";        
    }
}
