/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import geomaps.*;

/**
 *
 * @author alexsander
 */
public class Pais{
    public String[] Pais = new String[255];
    
    public Pais(){
        Pais[7] = "Alemanha";
        Pais[8] = "Austrália";
        Pais[9] = "Brasil";
        Pais[10] = "Camarões";
        Pais[11] = "Canadá";
        Pais[12] = "Chile";
        Pais[13] = "Estados Unidos";
        Pais[14] = "México";
        Pais[15] = "Portugal";
        Pais[16] = "Rússia";
        Pais[17] = "Equador";
        Pais[18] = "Inglaterra";
        Pais[19] = "Argentina";
        Pais[20] = "Polônia";
        Pais[21] = "Israel";
    }
}

