/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import geomaps.*;
import java.awt.Image;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

    /**
     * Creates new form form
     */
/**
 *
 * @author alexsander
 */
public class MapaMundiOceanos {
public Image[] map = new Image[255];
    
    public MapaMundiOceanos(){
         try {
            map[0] = ImageIO.read(MapaMundiOceanos.class.getResource("/Imagens/oceano/oceano atlantico.png"));
            map[1] = ImageIO.read(MapaMundiOceanos.class.getResource("/Imagens/oceano/oceano glacial antartico.png"));
            map[2] = ImageIO.read(MapaMundiOceanos.class.getResource("/Imagens/oceano/oceano glacial artico.png"));
            map[3] = ImageIO.read(MapaMundiOceanos.class.getResource("/Imagens/oceano/oceano indico.png"));
            map[4] = ImageIO.read(MapaMundiOceanos.class.getResource("/Imagens/oceano/oceano pacifico.png"));        
            } catch (IOException ex) {
            Logger.getLogger(MapaMundiOceanos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public Image getMap(int i) {
        return this.map[i];
    }    
}
