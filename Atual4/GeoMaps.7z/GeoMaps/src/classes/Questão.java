/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.ArrayList;

/**
 *
 * @author alexsander
 */
public class Questão {

    //int answer1, answer2, answer3, answer4, answer5, Resposta;
    public ArrayList<Integer> MyList = new ArrayList<Integer>();//lista responsável por armazenar os valores responsáveis pelas respostas geradas nas radio buttons
    public ArrayList<String> MyListErros = new ArrayList<String>();//lista que armazena o nome de um estado, por exemplo, que o usuário errou
    int acertos, erros;

    public Questão(int acerto, int erro) {
        this.acertos = acerto;
        this.erros = erro;
    }
    
    public boolean VerificaMyList(int averigua) {//verifica se o valor gerado pela função AnswerRandInt existe na lista MyList. Se não existir, inclui o valor na lista
        if (MyList.contains(averigua)) {
            return false;
        } else {
            SetList(averigua);
            return true;
        }
    }

    public int AnswerRandInt(int min, int max) {//gera um valor aleatorio para a lista de respostas possíveis 
        java.util.Random rand = new java.util.Random();
        int randomNum = rand.nextInt((max - min) + 1) + min;

        while (!VerificaMyList(randomNum)) {
            randomNum = rand.nextInt((max - min) + 1) + min;
        }
        return randomNum;
    }

    public void SetListaErros(String erro) {
        MyListErros.add(erro);
    }
    
    public void SetList(int val) {
        MyList.add(val);
    }
    
    public void ClearMyList() {//se o jogador desejar jogar novamente ou mesmo em outro modo de jogo, é nessário que os valores dá lista estejam vazios
        MyList.clear();
    }

    public ArrayList GetListaErros() {
        return MyListErros;
    }

    public int GetAcertos() {
        return acertos;
    }
    
    public int GetErros() {
        return erros;
    }

    public void SetAcertos(int val) {
        this.acertos = val;
    }

    public void SetErros(int val) {
        this.erros = val;
    }

}
