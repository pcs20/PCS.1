/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.awt.Image;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author alexsander
 */
public class MapaContinentesPaises {

    public Image[] map = new Image[255];

    public MapaContinentesPaises() {
        try {
        //continentes
        map[0] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/continente/africa.png"));
        map[1] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/continente/america central.png"));
        map[2] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/continente/america do norte.png"));
        map[3] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/continente/america sul.png"));
        map[4] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/continente/asia.png"));
        map[5] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/continente/europa.png"));
        map[6] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/continente/oceania.png"));
        //países
        map[7] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/alemanha.png"));
        map[8] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/australia.png"));
        map[9] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/brasil.png"));
        map[10] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/camaroes.png"));
        map[11] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/canadá.png"));
        map[12] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/chile.png"));
        map[13] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/estados unidos.png"));
        map[14] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/mexico.png"));
        map[15] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/portugal.png"));
        map[16] = ImageIO.read(MapaContinentesPaises.class.getResource("/Imagens/países/russia.png"));
         } catch (IOException ex) {
            Logger.getLogger(MapaContinentesPaises.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public Image getMap(int i) {
        return this.map[i];
    }
}
