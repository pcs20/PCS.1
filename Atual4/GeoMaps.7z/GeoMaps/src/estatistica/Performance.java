/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estatistica;

import java.util.ArrayList;

/**
 *
 * @author alexsander
 */
public class Performance {
    int acertos, erros;
    public ArrayList<String> GetMyListErros = new ArrayList<String>();
    
    public Performance(int acerto, int erro, ArrayList<String> MeusErrosEmLista){
        this.acertos = acerto;
        this.erros = erro;
        this.GetMyListErros = MeusErrosEmLista;        
    }
    
    public int SetAcertos(int val){
        this.acertos = val;
        return acertos;
    }
    
    public int SetErros(int val){
        this.erros = val;
        return erros;
    }
    
    public ArrayList SetMeusErros(ArrayList recebe){
        this.GetMyListErros = recebe;
        return GetMyListErros;
    }
    
    public int GetAcertos(){
        return acertos;
    }
    
    public int GetErros(){
        return erros;
    }
    
    public ArrayList GetMeusErros(){
        return GetMyListErros;
    }
    
}
