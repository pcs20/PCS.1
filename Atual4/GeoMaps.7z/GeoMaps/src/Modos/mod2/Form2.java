/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modos.mod2;

import Modos.mod1.*;
import classes.Questão;

import classes.Estados;
import classes.MapaEstadosBrasil;
import javax.swing.ImageIcon;
import java.io.IOException;
import Modos.NewJFrame1;
import static Modos.mod1.Form1.guest;
import static Modos.mod1.Form1.round;
import classes.MapaContinentesPaises;
import classes.Pais;
import classes.Rodada;
import classes.continente;
import java.awt.Image;
import java.io.IOException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author alexsander
 */
public class Form2 extends javax.swing.JFrame {

    int maxAcertos = 10, captura = 0;
    int min = 1, max = 5;

    //Form form = new Form();  
    private MapaContinentesPaises MapContinentesPaises = new MapaContinentesPaises();

    private static continente continente = new continente();
    private static Pais pais = new Pais();
    public static Questão guest;
    public static Rodada round;
//gera numero aletoio entre 1 e 5

    public int Random() {
        java.util.Random rand = new java.util.Random();
        int randomNum = rand.nextInt((max - min) + 1) + min;
        captura = randomNum;
        return captura;
    }
//seta resposta correta em algum radio buttons

    public void RandomRespostaCorreta() {
        Random();
        if (guest.VerificaMyList(round.randomNum)) {//verificará se a resposta já existe em algum radio buttons para não haver mais de um com a mesma resposta
            if (captura == 1) {
                if (round.randomNum > 6) {
                    Resposta1.setText(pais.Pais[round.randomNum]);
                } else {
                    Resposta1.setText(continente.Continente[round.randomNum]);
                }
            } else if (captura == 2) {
                if (round.randomNum > 6) {
                    Resposta2.setText(pais.Pais[round.randomNum]);
                } else {
                    Resposta2.setText(continente.Continente[round.randomNum]);
                }
            } else if (captura == 3) {
                if (round.randomNum > 6) {
                    Resposta3.setText(pais.Pais[round.randomNum]);
                } else {
                    Resposta3.setText(continente.Continente[round.randomNum]);
                }
            } else if (captura == 4) {
                if (round.randomNum > 6) {
                    Resposta4.setText(pais.Pais[round.randomNum]);
                } else {
                    Resposta4.setText(continente.Continente[round.randomNum]);
                }
            } else if (captura == 5) {
                if (round.randomNum > 6) {
                    Resposta5.setText(pais.Pais[round.randomNum]);
                } else {
                    Resposta5.setText(continente.Continente[round.randomNum]);
                }
            }
        }
    }
//seta texto resposta para os radio buttons

    public void Modifica() {
        Resposta1.setText(continente.Continente[guest.AnswerRandInt(0, 6)]);
        Resposta2.setText(continente.Continente[guest.AnswerRandInt(0, 6)]);
        Resposta3.setText(pais.Pais[guest.AnswerRandInt(7, 21)]);
        Resposta4.setText(pais.Pais[guest.AnswerRandInt(7, 21)]);
        Resposta5.setText(pais.Pais[guest.AnswerRandInt(7, 21)]);
    }
//contabilizo numero de erros e acertos

    public void SetAcertosErros() {
        if (Resposta1.getText() == continente.Continente[round.randomNum] && Resposta1.isSelected() == true || Resposta1.getText() == pais.Pais[round.randomNum] && Resposta1.isSelected() == true
                || Resposta2.getText() == continente.Continente[round.randomNum] && Resposta2.isSelected() == true || Resposta2.getText() == pais.Pais[round.randomNum] && Resposta2.isSelected() == true
                || Resposta3.getText() == pais.Pais[round.randomNum] && Resposta3.isSelected() == true || Resposta3.getText() == continente.Continente[round.randomNum] && Resposta3.isSelected() == true
                || Resposta4.getText() == pais.Pais[round.randomNum] && Resposta4.isSelected() == true || Resposta4.getText() == continente.Continente[round.randomNum] && Resposta4.isSelected() == true
                || Resposta5.getText() == pais.Pais[round.randomNum] && Resposta5.isSelected() == true || Resposta5.getText() == continente.Continente[round.randomNum] && Resposta5.isSelected() == true) {
        } else {
            if (round.randomNum > 6) {
                guest.SetListaErros(pais.Pais[round.randomNum]);//armazena o nome dos estados errados
            } else {
                guest.SetListaErros(continente.Continente[round.randomNum]);
            }
        }
    }

    public Form2() {
        initComponents();
        round = new Rodada();
        guest = new Questão(0, 0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jButton1 = new javax.swing.JButton();
        seleciona_pla = new javax.swing.JLabel();
        Resposta1 = new javax.swing.JRadioButton();
        Resposta4 = new javax.swing.JRadioButton();
        Resposta5 = new javax.swing.JRadioButton();
        Resposta2 = new javax.swing.JRadioButton();
        Resposta3 = new javax.swing.JRadioButton();
        imagemMOD2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icone_próximo.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        seleciona_pla.setText("Selecione:");

        buttonGroup1.add(Resposta1);
        Resposta1.setText("África");
        Resposta1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Resposta1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(Resposta4);
        Resposta4.setSelected(true);
        Resposta4.setText("Alemanha");
        Resposta4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Resposta4ActionPerformed(evt);
            }
        });

        buttonGroup1.add(Resposta5);
        Resposta5.setText("Brasil");
        Resposta5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Resposta5ActionPerformed(evt);
            }
        });

        buttonGroup1.add(Resposta2);
        Resposta2.setText("América Sul");
        Resposta2.setActionCommand("América do Sul");
        Resposta2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Resposta2ActionPerformed(evt);
            }
        });

        buttonGroup1.add(Resposta3);
        Resposta3.setText("Chile");
        Resposta3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Resposta3ActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icone_play.png"))); // NOI18N
        jButton2.setText("Iniciar");
        jButton2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton2.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Resposta2)
                            .addComponent(Resposta4)
                            .addComponent(Resposta1)
                            .addComponent(Resposta5)
                            .addComponent(Resposta3))))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(imagemMOD2, javax.swing.GroupLayout.PREFERRED_SIZE, 649, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 60, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(seleciona_pla, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(imagemMOD2, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(seleciona_pla)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Resposta3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Resposta5)
                        .addGap(7, 7, 7)
                        .addComponent(Resposta2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Resposta1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Resposta4)))
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Resposta4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Resposta4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Resposta4ActionPerformed

    private void Resposta5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Resposta5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Resposta5ActionPerformed

    private void Resposta1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Resposta1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Resposta1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        SetAcertosErros();//verifica resposta do usuário
        if (round.ListaCheia(10)) {
            guest.SetAcertos(maxAcertos-guest.MyListErros.size());
            guest.SetErros(guest.MyListErros.size());
            
            round.ClearList();//limpa lista de armazenamento
            guest.ClearMyList();//limpa lista de armazenamento
            this.setVisible(false);
            JOptionPane.showMessageDialog(null, "Modo 2 -> Término");
        }
        

        ImageIcon icon = new ImageIcon(MapContinentesPaises.getMap(round.QuestRandInt(0, 16)));//seta nova imagem p/ rodada
        imagemMOD2.setIcon(icon);
        Modifica();//joga valores aleatórios para as radio buttons
        RandomRespostaCorreta();//gera resposta correta para alguma radio buttons de forma aleatoria
        guest.ClearMyList();//limpa lista de armazenamento
        //-------------------------------------------------------------------------------//
    }//GEN-LAST:event_jButton1ActionPerformed

    private void Resposta2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Resposta2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Resposta2ActionPerformed

    private void Resposta3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Resposta3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Resposta3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Random();
        ImageIcon icon = new ImageIcon(MapContinentesPaises.getMap(round.QuestRandInt(0, 9)));
        imagemMOD2.setIcon(icon);
        Modifica();
        RandomRespostaCorreta();
        guest.ClearMyList();
        jButton2.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton Resposta1;
    private javax.swing.JRadioButton Resposta2;
    private javax.swing.JRadioButton Resposta3;
    private javax.swing.JRadioButton Resposta4;
    private javax.swing.JRadioButton Resposta5;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel imagemMOD2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel seleciona_pla;
    // End of variables declaration//GEN-END:variables
}
